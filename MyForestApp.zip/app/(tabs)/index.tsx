import ForestScreen from '../screens/ForestScreen';

export default ForestScreen;
